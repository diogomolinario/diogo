static char	ident[] = "@(#)(N)compress 4.2.4.5";
#define	version_id (ident+4)
